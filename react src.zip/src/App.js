import React, { useEffect, useState } from 'react'
import axios from "axios"
export default function App() {
  const [User, setUser] = useState({userId:"",userrName:"",userEmail:""})
 useEffect(()=>{
   axios.get("/api/user")
    .then(response=>{
      console.log(response.data)
      setUser(response.data[1])
   })
   return()=>{}
 },[])
function handleClick(){
  axios({
    method:'post',
    url:'api/user/add',
    data:{
     UserId:50,
      UserName:"caca",
      userEmail:"caca@gmail.com"
    }
  });
}
function handleDelete() {
  axios({
      method: 'delete',
      url: 'api/user/delete/50 '
  });
}
  return (
    <div>
            <br></br>
      <br></br>
      <h2>My User details are:  {JSON.stringify(User)}</h2>
      <button onClick={handleClick}>Post to Spring</button>
      <button onClick={handleDelete}>delete to Spring</button>
    </div>
  )
}